import { test } from '@playwright/test';
import { LoginPage } from '../Pages/LoginPage';

test('logs in with valid credentials', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.open();
  await loginPage.login('standard_user', 'secret_sauce');
  await loginPage.expectLoginSuccessful();
});